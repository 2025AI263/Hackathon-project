"""
utils/helpers.py
-----------------
Shared helper: loads the REAL pretrained face embedding model and
converts a cropped face image into a 512-number embedding vector.

WHAT IS A FACE EMBEDDING?
A face embedding is a list of numbers (a vector) that represents a face's
identity. The pretrained model has learned to output vectors such that:
  - Two photos of the SAME person produce vectors that are close together
    (small distance between them).
  - Two photos of DIFFERENT people produce vectors that are far apart
    (large distance).
This lets us do face recognition as simple math: compare vectors, don't
need to re-train anything for a new person — just compute their vector.

MODEL USED: InceptionResnetV1 from the `facenet-pytorch` library,
pretrained on the VGGFace2 dataset. It outputs a 512-dimensional
embedding per face. This is a well-established, widely used pretrained
face recognition model (FaceNet architecture).

PREPROCESSING (required by this exact model — do not change):
  1. Resize the cropped face to 160x160 pixels.
  2. Convert BGR (OpenCV default) to RGB.
  3. Normalize pixel values: (pixel - 127.5) / 128.0, giving a roughly
     [-1, 1] range, which is what this model was trained on.
  4. Rearrange to (channels, height, width) and add a batch dimension,
     which is the tensor shape PyTorch models expect.
"""

import cv2
import numpy as np
import torch
from facenet_pytorch import InceptionResnetV1


class FaceEmbedder:
    _instance = None  # simple singleton so the model loads only once

    def __init__(self):
        self.device = torch.device("cpu")
        # pretrained="vggface2" downloads model weights (~110MB) the first
        # time this runs, and caches them locally afterward.
        self.model = InceptionResnetV1(pretrained="vggface2").eval().to(self.device)

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def preprocess(self, face_bgr_image):
        face = cv2.resize(face_bgr_image, (160, 160))
        face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        face = (face.astype(np.float32) - 127.5) / 128.0
        tensor = torch.from_numpy(face).permute(2, 0, 1).unsqueeze(0)
        return tensor.to(self.device)

    def get_embedding(self, face_bgr_image) -> np.ndarray:
        """
        Args:
            face_bgr_image: a cropped face image, BGR, any size (will be
                             resized internally).
        Returns:
            numpy array of shape (512,) — the face embedding.
        """
        tensor = self.preprocess(face_bgr_image)
        with torch.no_grad():
            embedding = self.model(tensor)
        return embedding.cpu().numpy().flatten()

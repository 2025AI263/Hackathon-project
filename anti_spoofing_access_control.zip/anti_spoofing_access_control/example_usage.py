"""
example_usage.py
-----------------
A minimal example for Person 1/3/4 showing how to use Person 2's module.
Run with:  python example_usage.py
(Needs a webcam connected to your computer — this is a plain OpenCV
script, separate from the Streamlit app, just to prove the module works.)
"""

import cv2
from face_recognition.recognizer import FaceRecognizer

recognizer = FaceRecognizer()

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise RuntimeError("Could not open webcam. Check it is connected and not used by another app.")

print("Press 'q' to quit.")

while True:
    ok, frame = cap.read()
    if not ok:
        print("Failed to read frame from camera.")
        break

    result = recognizer.recognize(frame)
    print(result)

    # Draw box + label if we have exactly one face
    if result.get("face_detected") and result.get("face_count") == 1 and "bbox" in result:
        x1, y1, x2, y2 = result["bbox"]
        label = result.get("name", "?")
        color = (0, 255, 0) if result.get("recognized") else (0, 0, 255)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        cv2.putText(frame, label, (x1, max(0, y1 - 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow("Person 2 module - press q to quit", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()

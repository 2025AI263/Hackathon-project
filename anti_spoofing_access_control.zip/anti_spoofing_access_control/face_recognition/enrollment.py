"""
face_recognition/enrollment.py
-------------------------------
Handles registering (enrolling) a new user: takes several photos of one
person, checks each photo is usable, generates a REAL embedding for each,
and saves them to the database.

Enrollment is rejected per-sample when:
  - No face is detected in that photo.
  - More than one face is detected in that photo (ambiguous — we don't
    know which face belongs to the person registering).
The whole enrollment fails only if ZERO usable samples were collected.
"""

from face_detection.detector import FaceDetector
from utils.helpers import FaceEmbedder
from database.database import Database


class EnrollmentManager:
    def __init__(self, db: Database, detector: FaceDetector = None, embedder: FaceEmbedder = None):
        self.db = db
        self.detector = detector or FaceDetector()
        self.embedder = embedder or FaceEmbedder.get_instance()

    def enroll(self, name: str, images: list):
        """
        Args:
            name: the person's name.
            images: list of BGR OpenCV images (numpy arrays), ideally 3-5
                    samples taken from slightly different angles.

        Returns:
            {
                "success": bool,
                "message": str,
                "samples_saved": int,
                "samples_rejected": int,
            }
        """
        if not name or not name.strip():
            return {"success": False, "message": "Name cannot be empty.",
                    "samples_saved": 0, "samples_rejected": 0}

        embeddings = []
        rejected = 0

        for image in images:
            detection = self.detector.detect(image)

            if detection["face_count"] == 0:
                rejected += 1
                continue
            if detection["face_count"] > 1:
                rejected += 1
                continue

            bbox = detection["faces"][0]["bbox"]
            face_crop = self.detector.crop_face(image, bbox)

            if face_crop is None or face_crop.size == 0:
                rejected += 1
                continue

            embedding = self.embedder.get_embedding(face_crop)
            embeddings.append(embedding)

        if len(embeddings) == 0:
            return {
                "success": False,
                "message": "Registration failed: no usable face samples "
                            "(make sure exactly one face is visible per photo).",
                "samples_saved": 0,
                "samples_rejected": rejected,
            }

        self.db.add_user(name.strip(), embeddings)

        return {
            "success": True,
            "message": f"Registration successful for {name.strip()}",
            "samples_saved": len(embeddings),
            "samples_rejected": rejected,
        }

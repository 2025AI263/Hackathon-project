"""
face_recognition/recognizer.py
--------------------------------
This is the MAIN PUBLIC INTERFACE of Person 2's module.
Person 3 and Person 4 should only ever need to import FaceRecognizer
from here — they don't need to know about detectors/embedders/database
internals.

Usage (see also example_usage.py):

    from face_recognition.recognizer import FaceRecognizer

    recognizer = FaceRecognizer()
    result = recognizer.recognize(frame)      # frame = BGR numpy image
    result = recognizer.enroll("Ali", images)  # images = list of BGR frames

IMPORTANT — WHAT recognize() DOES **NOT** DO:
This module ONLY makes the AUTHORIZED/UNKNOWN decision. It does NOT know
anything about liveness (spoof detection) and does NOT decide final
access. That combination happens in the team's integration layer
(see README "Integration with liveness module"):

    if liveness == "SPOOF":
        access = "DENIED"
    elif liveness == "LIVE" and recognition_result["recognized"]:
        access = "GRANTED"
    else:
        access = "DENIED"
"""

import numpy as np

from face_detection.detector import FaceDetector
from face_recognition.enrollment import EnrollmentManager
from utils.helpers import FaceEmbedder
from database.database import Database
from config import RECOGNITION_THRESHOLD, DB_PATH


class FaceRecognizer:
    def __init__(self, db_path: str = DB_PATH, threshold: float = RECOGNITION_THRESHOLD):
        self.threshold = threshold
        self.detector = FaceDetector()
        self.embedder = FaceEmbedder.get_instance()
        self.db = Database(db_path)
        self.enrollment_manager = EnrollmentManager(self.db, self.detector, self.embedder)

    # ---------- ENROLLMENT ----------
    def enroll(self, name: str, images: list) -> dict:
        """Register a new user from a list of BGR face photos. See enrollment.py."""
        return self.enrollment_manager.enroll(name, images)

    # ---------- RECOGNITION ----------
    def recognize(self, frame) -> dict:
        """
        Run full detect -> embed -> compare pipeline on one frame.

        Returns one of these shapes:

        No face:
            {"face_detected": False, "face_count": 0, "message": "..."}

        Multiple faces (no decision made, per spec):
            {"face_detected": True, "face_count": N, "message": "..."}

        Exactly one face, no users registered yet:
            {"face_detected": True, "face_count": 1, "name": "Unknown",
             "recognized": False, "distance": None, "bbox": [...],
             "message": "No registered users yet"}

        Exactly one face, compared against registered users:
            {"face_detected": True, "face_count": 1, "name": str,
             "recognized": bool, "distance": float, "bbox": [x1,y1,x2,y2]}
        """
        detection = self.detector.detect(frame)

        if detection["face_count"] == 0:
            return {"face_detected": False, "face_count": 0,
                    "message": "No face detected"}

        if detection["face_count"] > 1:
            return {"face_detected": True, "face_count": detection["face_count"],
                    "message": "Multiple faces detected - no access decision made"}

        bbox = detection["faces"][0]["bbox"]
        face_crop = self.detector.crop_face(frame, bbox)

        if face_crop is None or face_crop.size == 0:
            return {"face_detected": True, "face_count": 1,
                    "message": "Face crop failed (face too close to frame edge)"}

        embedding = self.embedder.get_embedding(face_crop)
        known_embeddings = self.db.get_all_embeddings()

        if not known_embeddings:
            return {
                "face_detected": True, "face_count": 1,
                "name": "Unknown", "recognized": False,
                "distance": None, "confidence": 0.0, "bbox": bbox,
                "message": "No registered users yet",
            }

        best_name, best_distance = self._find_best_match(embedding, known_embeddings)
        recognized = best_distance < self.threshold

        return {
            "face_detected": True,
            "face_count": 1,
            "name": best_name if recognized else "Unknown",
            "recognized": recognized,
            "distance": float(best_distance),
            "confidence": self._distance_to_confidence(best_distance),
            "bbox": bbox,
        }

    def _distance_to_confidence(self, distance: float) -> float:
        """
        Converts the raw embedding distance into a 0-100 'confidence' number
        for display in the UI / logging, since the team's database and
        dashboard expect a confidence value alongside the distance.

        This is a simple heuristic linear mapping, NOT a statistically
        calibrated probability: confidence = 100% at distance 0, and drops
        to 0% at distance = 2x the recognition threshold. Use `distance`
        (not this number) for any real accept/reject logic.
        """
        max_distance_for_zero_confidence = self.threshold * 2
        confidence = 100.0 * (1.0 - (distance / max_distance_for_zero_confidence))
        return round(max(0.0, min(100.0, confidence)), 1)

    @staticmethod
    def _find_best_match(embedding, known_embeddings):
        """
        Compares the new embedding against every stored embedding using
        Euclidean distance and returns the closest match.

        NOTE: this is a real Euclidean distance between real embedding
        vectors — not a fabricated number. Smaller distance = more similar
        faces. There is no universally "correct" distance-to-probability
        conversion for this model, so we report the raw distance rather
        than inventing a percentage confidence.
        """
        best_name = None
        best_distance = float("inf")
        for name, known_embedding in known_embeddings:
            distance = float(np.linalg.norm(embedding - known_embedding))
            if distance < best_distance:
                best_distance = distance
                best_name = name
        return best_name, best_distance

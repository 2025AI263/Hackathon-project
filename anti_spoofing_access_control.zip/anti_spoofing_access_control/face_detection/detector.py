"""
face_detection/detector.py
---------------------------
Real-time face detection using MediaPipe Face Detection.

Why MediaPipe instead of dlib/Haar cascades?
- It is pip-installable with no separate model file to download and manage
  (the model ships inside the mediapipe package itself).
- It works reliably on Streamlit Community Cloud (pure Python + prebuilt
  wheels, no C++ compiler needed at install time).
- It is fast enough for real-time use on CPU.

COORDINATE SYSTEM:
MediaPipe returns bounding boxes as RELATIVE coordinates (0.0 to 1.0),
meaning they are fractions of the image width/height. This module converts
them into ABSOLUTE pixel coordinates (x1, y1, x2, y2), where:
    x1, y1 = top-left corner of the face box (in pixels)
    x2, y2 = bottom-right corner of the face box (in pixels)
This is the standard OpenCV convention: (0,0) is the top-left of the image,
x increases to the right, y increases downward.
"""

import cv2
import mediapipe as mp


class FaceDetector:
    def __init__(self, min_confidence: float = 0.6):
        """
        Args:
            min_confidence: minimum detection confidence (0.0-1.0).
                             Higher = fewer false detections but might miss
                             faces in poor lighting or at odd angles.
        """
        self._mp_face_detection = mp.solutions.face_detection
        # model_selection=1 -> "full range" model, better for faces that are
        # farther from the camera (more realistic for an access-control kiosk).
        self._detector = self._mp_face_detection.FaceDetection(
            model_selection=1,
            min_detection_confidence=min_confidence,
        )

    def detect(self, frame):
        """
        Detect faces in a single BGR OpenCV frame.

        Args:
            frame: numpy array (H, W, 3) in BGR order, as returned by
                   cv2.imread / cv2.VideoCapture / cv2.imdecode.

        Returns:
            {
                "face_detected": bool,
                "face_count": int,
                "faces": [
                    {"bbox": [x1, y1, x2, y2], "confidence": float},
                    ...
                ]
            }
        """
        if frame is None or frame.size == 0:
            return {"face_detected": False, "face_count": 0, "faces": []}

        h, w = frame.shape[:2]
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self._detector.process(rgb_frame)

        faces = []
        if results.detections:
            for detection in results.detections:
                rel_box = detection.location_data.relative_bounding_box

                x1 = int(rel_box.xmin * w)
                y1 = int(rel_box.ymin * h)
                box_w = int(rel_box.width * w)
                box_h = int(rel_box.height * h)

                # Clip to image bounds — MediaPipe can return slightly
                # out-of-frame boxes near the edges.
                x1 = max(0, x1)
                y1 = max(0, y1)
                x2 = min(w, x1 + box_w)
                y2 = min(h, y1 + box_h)

                if x2 <= x1 or y2 <= y1:
                    continue  # invalid / degenerate box, skip it

                confidence = float(detection.score[0]) if detection.score else 0.0

                faces.append({
                    "bbox": [x1, y1, x2, y2],
                    "confidence": confidence,
                })

        return {
            "face_detected": len(faces) > 0,
            "face_count": len(faces),
            "faces": faces,
        }

    def crop_face(self, frame, bbox, margin: float = 0.2):
        """
        Crop a face out of the frame, with a small margin around the box
        (helps the recognition model see a bit of context around the face).

        Args:
            frame: the original BGR frame.
            bbox: [x1, y1, x2, y2] as returned by detect().
            margin: extra fraction of the box size to include on each side.

        Returns:
            Cropped BGR image (numpy array). May be empty if bbox is invalid.
        """
        h, w = frame.shape[:2]
        x1, y1, x2, y2 = bbox
        box_w = x2 - x1
        box_h = y2 - y1

        mx = int(box_w * margin)
        my = int(box_h * margin)

        x1 = max(0, x1 - mx)
        y1 = max(0, y1 - my)
        x2 = min(w, x2 + mx)
        y2 = min(h, y2 + my)

        return frame[y1:y2, x1:x2]

    def draw_boxes(self, frame, faces):
        """
        Draw green rectangles around detected faces. Returns a NEW image
        (does not modify the original frame).
        """
        output = frame.copy()
        for face in faces:
            x1, y1, x2, y2 = face["bbox"]
            cv2.rectangle(output, (x1, y1), (x2, y2), (0, 255, 0), 2)
        return output

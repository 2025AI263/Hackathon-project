"""
calibrate_threshold.py
------------------------
Helps you pick a real RECOGNITION_THRESHOLD using actual measurements,
instead of guessing. This does NOT fake any numbers - it reads photos
you provide and computes real distances between real embeddings.

HOW TO USE:
1. Create a folder structure like this with real photos of your team:

    calibration_data/
        Ali/
            1.jpg
            2.jpg
            3.jpg
        Sara/
            1.jpg
            2.jpg
        Unknown/
            1.jpg   (photos of people NOT registered)
            2.jpg

   Take these photos under conditions similar to your demo (same room,
   similar lighting/distance) for a realistic threshold.

2. Run:
       python calibrate_threshold.py

3. Read the printed "genuine" and "impostor" distance statistics, and
   set RECOGNITION_THRESHOLD in config.py to a value between the
   typical genuine distance and the typical impostor distance
   (closer to the impostor side if you want to be stricter).
"""

import os
import cv2
import numpy as np

from face_detection.detector import FaceDetector
from utils.helpers import FaceEmbedder

CALIBRATION_DIR = "calibration_data"


def load_embeddings_by_person(detector, embedder):
    people = {}
    if not os.path.isdir(CALIBRATION_DIR):
        raise SystemExit(
            f"'{CALIBRATION_DIR}/' not found. Create it and add subfolders "
            f"of photos per person (see the docstring at the top of this file)."
        )

    for person_name in sorted(os.listdir(CALIBRATION_DIR)):
        person_dir = os.path.join(CALIBRATION_DIR, person_name)
        if not os.path.isdir(person_dir):
            continue

        embeddings = []
        for filename in sorted(os.listdir(person_dir)):
            path = os.path.join(person_dir, filename)
            image = cv2.imread(path)
            if image is None:
                print(f"  Skipping unreadable file: {path}")
                continue

            detection = detector.detect(image)
            if detection["face_count"] != 1:
                print(f"  Skipping {path}: found {detection['face_count']} face(s), need exactly 1")
                continue

            bbox = detection["faces"][0]["bbox"]
            crop = detector.crop_face(image, bbox)
            embeddings.append(embedder.get_embedding(crop))

        if embeddings:
            people[person_name] = embeddings
            print(f"Loaded {len(embeddings)} usable sample(s) for '{person_name}'")

    return people


def main():
    detector = FaceDetector()
    embedder = FaceEmbedder.get_instance()

    print("Loading and embedding calibration photos...\n")
    people = load_embeddings_by_person(detector, embedder)

    if len(people) < 2:
        raise SystemExit("Need at least 2 people (including an 'Unknown' folder) with usable photos.")

    genuine_distances = []
    impostor_distances = []

    names = list(people.keys())
    for i, name_a in enumerate(names):
        embeddings_a = people[name_a]

        # Genuine pairs: same person, different samples
        for x in range(len(embeddings_a)):
            for y in range(x + 1, len(embeddings_a)):
                dist = np.linalg.norm(embeddings_a[x] - embeddings_a[y])
                genuine_distances.append(dist)

        # Impostor pairs: this person vs every other person
        for name_b in names[i + 1:]:
            embeddings_b = people[name_b]
            for emb_a in embeddings_a:
                for emb_b in embeddings_b:
                    dist = np.linalg.norm(emb_a - emb_b)
                    impostor_distances.append(dist)

    print("\n--- RESULTS (real measured distances) ---")
    if genuine_distances:
        g = np.array(genuine_distances)
        print(f"Genuine pairs (same person):    n={len(g)}  "
              f"min={g.min():.3f}  mean={g.mean():.3f}  max={g.max():.3f}")
    else:
        print("No genuine pairs found (need 2+ photos of at least one person).")

    if impostor_distances:
        imp = np.array(impostor_distances)
        print(f"Impostor pairs (different people): n={len(imp)}  "
              f"min={imp.min():.3f}  mean={imp.mean():.3f}  max={imp.max():.3f}")
    else:
        print("No impostor pairs found (need 2+ people).")

    if genuine_distances and impostor_distances:
        suggested = (np.array(genuine_distances).max() + np.array(impostor_distances).min()) / 2
        print(f"\nSuggested starting threshold (midpoint): {suggested:.3f}")
        print("Set this in config.py -> RECOGNITION_THRESHOLD")
        print("If genuine max > impostor min (overlap), no single threshold is perfect - "
              "collect more/better photos or adjust lighting/distance for the demo.")


if __name__ == "__main__":
    main()

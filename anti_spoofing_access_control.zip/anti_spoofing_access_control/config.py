"""
config.py
---------
Central place for all settings used by Person 2's module.
Change values here instead of hunting through the code.
"""

# --- Face detection settings ---
# Minimum confidence (0.0 - 1.0) for MediaPipe to count something as a face.
DETECTION_CONFIDENCE = 0.6

# --- Face recognition settings ---
# This is a STARTING value only. You MUST calibrate this using real
# measurements from your own camera/team before the hackathon demo.
# Lower distance = stricter (fewer false accepts, more false rejects).
# Higher distance = looser (more false accepts, fewer false rejects).
# See PART 7 (threshold calibration) in the README for how to pick this.
RECOGNITION_THRESHOLD = 0.9

# Embedding size produced by the facenet-pytorch InceptionResnetV1 model.
EMBEDDING_SIZE = 512

# --- Storage settings ---
DB_PATH = "database/faces.db"

# Anti-Spoofing Access Control — Person 2 Module (Face Detection & Recognition)

## 1. Project description
This is Person 2's part of a 4-person hackathon project: **"Anti-Spoofing Face
Liveness Detection for Robust AI-Based Access Control System."** This module
handles real face detection, face enrollment, real face embeddings, and
comparing a live face against registered users to decide **AUTHORIZED** or
**UNKNOWN**. It does **not** decide liveness (Person 1) or final access
(Person 3), and does not build the full dashboard (Person 4).

## 2. Architecture
```
Camera / photo
      |
FaceDetector (MediaPipe)  -> bounding box(es)
      |
crop_face()                -> cropped face image
      |
FaceEmbedder (facenet-pytorch, InceptionResnetV1)
      |
512-number embedding vector
      |
compare against embeddings in database/faces.db  (Euclidean distance)
      |
AUTHORIZED (name) or UNKNOWN
```
This result is handed to the team's integration layer (Person 3), which
combines it with Person 1's liveness result:
```python
if liveness == "SPOOF":
    access = "DENIED"
elif liveness == "LIVE" and recognition_result["recognized"]:
    access = "GRANTED"
else:
    access = "DENIED"
```

## 3. Technology choice
| Option | Pros | Cons | Verdict |
|---|---|---|---|
| `face_recognition` (dlib) | Very popular, simple API | Needs `cmake`/C++ build tools; frequently **fails to install on Streamlit Cloud** | Rejected |
| InsightFace (ArcFace, ONNX) | Very accurate | Larger models, more setup for a beginner, extra ONNX runtime dependency | Good, but heavier for a first-timer |
| **facenet-pytorch + MediaPipe** | Pure pip install, no compiler needed, MediaPipe ships its detection model inside the package (nothing to download/manage), reliable on Streamlit Cloud | `torch` is a fairly large dependency | **Selected** |

This combination is the most reliable path to a **working deployed demo**
for a beginner on a deadline.

## 4. Folder structure
```
anti_spoofing_access_control/
├── app.py                     # Streamlit test dashboard (this module only)
├── example_usage.py           # Plain OpenCV example for teammates
├── calibrate_threshold.py     # Real threshold calibration tool
├── requirements.txt
├── README.md
├── .gitignore
├── config.py                  # RECOGNITION_THRESHOLD and other settings
├── face_detection/
│   ├── __init__.py
│   └── detector.py            # FaceDetector class
├── face_recognition/
│   ├── __init__.py
│   ├── recognizer.py          # FaceRecognizer - MAIN PUBLIC INTERFACE
│   └── enrollment.py          # EnrollmentManager
├── utils/
│   ├── __init__.py
│   └── helpers.py             # FaceEmbedder (loads the pretrained model)
├── database/
│   ├── __init__.py
│   └── database.py            # SQLite storage
└── data/registered_faces/     # (currently unused placeholder)
```

## 5. Installation (local setup)
Open a terminal in the project folder and run:

```bash
python -m venv venv
```
**Windows (PowerShell):**
```bash
venv\Scripts\activate
```
**Mac/Linux:**
```bash
source venv/bin/activate
```
Then install dependencies:
```bash
pip install -r requirements.txt
```
This will take a few minutes the first time (downloading `torch`).

## 6. Running locally
```bash
streamlit run app.py
```
This opens a browser tab. Use the sidebar to switch between **Register a
user** and **Recognize a face**.

The very first time you click anything that touches the model, the
`facenet-pytorch` model weights (~110MB) will download automatically and
be cached — this needs an internet connection once.

## 7. Enrollment
Go to **Register a user**, type a name, take 3–5 photos (move your head
slightly between each), click **Register**. Photos with zero or more than
one face are automatically rejected and don't count toward your samples.

## 8. Recognition
Go to **Recognize a face**, take a photo. You'll see the detected face box,
`AUTHORIZED`/`UNKNOWN`, and the raw recognition distance.

## 9. Threshold calibration (important — do this before the hackathon)
The default `RECOGNITION_THRESHOLD = 0.9` in `config.py` is a **reasonable
starting point for this exact model**, not a guaranteed-correct value —
the right threshold depends on your camera, lighting, and how many people
you enroll. To calibrate it with real numbers:

1. Create a `calibration_data/` folder with a subfolder per person
   (including an `Unknown/` folder of people who are NOT registered),
   each containing a few real photos taken like your demo setup.
2. Run:
   ```bash
   python calibrate_threshold.py
   ```
3. It prints real **genuine** (same person) and **impostor** (different
   people) distance statistics and suggests a threshold. Put that number
   into `config.py`.

Test at minimum: same authorized person, a different authorized person, an
unknown person, different lighting, different distance, and different
face angles — exactly as required by the team's test plan.

## 10. Team integration
Import only this class:
```python
from face_recognition.recognizer import FaceRecognizer

recognizer = FaceRecognizer()
result = recognizer.recognize(frame)   # frame = BGR numpy image (OpenCV)
```
`result` always includes `face_detected` and (when exactly one face is
found) `name`, `recognized`, `distance`, `bbox`. This module never makes
the final GRANTED/DENIED call — that's Person 3's job, combined with
Person 1's liveness output as shown in section 2.

## 11. GitHub setup
```bash
git init
git add .
git commit -m "Person 2: face detection and recognition module"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
`.gitignore` already excludes `__pycache__/`, virtual environments, and
the local `faces.db` (don't commit real biometric data or secrets).

## 12. Streamlit Cloud deployment
1. Push this project to a GitHub repository (see above).
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click **New app**, select your repository and branch.
4. Set the main file path to `app.py`.
5. Click **Deploy**.
6. If it fails, open **Manage app -> Logs** to see the error (see
   Troubleshooting below for common ones).
7. First load will be slow (installing `torch`/`mediapipe` and
   downloading model weights) — this is normal.

## 13. Limitations
- `st.camera_input` captures single snapshots, not continuous live video
  (see the note at the top of `app.py`).
- SQLite storage on Streamlit Cloud is **not permanent** across
  redeployments/container recycling — fine for a demo, not production
  (see the big comment in `database/database.py`).
- Recognition distance is a raw mathematical distance, not a scientifically
  calibrated probability — we report it as-is rather than inventing a
  percentage.

## 14. Security notes
- Face recognition and liveness detection are **separate security layers**
  — recognizing a face does not by itself prove the person is physically
  present (that's exactly why the liveness module exists).
- Never bypass the liveness check in final integration.
- No system in this project claims 100% security.
- No secrets/API keys are stored in this repo; use Streamlit Secrets
  (`.streamlit/secrets.toml`, gitignored) if the team later needs any.

## 15. Troubleshooting
| Problem | Likely cause / fix |
|---|---|
| `ModuleNotFoundError: No module named 'face_recognition'` | You're running from the wrong folder, or the local `face_recognition/` folder isn't next to `app.py`. Run Streamlit from the project root. |
| `ImportError: libGL.so.1` on Streamlit Cloud | Happens with `opencv-python` (needs a display). We use `opencv-python-headless` in requirements.txt specifically to avoid this — make sure you didn't accidentally install both. |
| App is very slow to start | Normal on first load — it's installing `torch`/`mediapipe` and downloading the ~110MB embedding model. Subsequent loads are faster. |
| Camera doesn't show in browser | Browser blocked camera permission — click the camera icon in the address bar and allow access. Streamlit Cloud requires HTTPS for camera access, which `share.streamlit.io` provides automatically. |
| Everyone is recognized as everyone else | Threshold too high — run `calibrate_threshold.py` and lower `RECOGNITION_THRESHOLD`. |
| No one is ever recognized, even themselves | Threshold too low, or lighting differs a lot between enrollment and recognition — re-enroll under demo lighting. |
| `sqlite3.OperationalError: unable to open database file` | The `database/` folder doesn't exist / isn't writable. It's created automatically by `Database.__init__`; make sure you didn't gitignore-and-then-manually-delete it in a way that breaks folder creation. |

"""
database/database.py
---------------------
Stores registered users and their face embeddings in a SQLite database.

WHY SQLITE:
- Zero setup — it's a single file, built into Python (no server to run).
- Easy for Person 3 to query too (SELECT name FROM face_embeddings ...).

HOW EMBEDDINGS ARE STORED:
A face embedding is just a list of 512 floating point numbers (a numpy
array). SQLite has no "array" column type, so we store it as a BLOB
(raw bytes) using `array.tobytes()`, and convert it back with
`np.frombuffer(blob, dtype=np.float32)` when reading.

IMPORTANT — STREAMLIT CLOUD PERSISTENCE LIMITATION (read this):
Streamlit Community Cloud's filesystem is EPHEMERAL. That means:
  - While your app is running, this faces.db file works completely
    normally and data is NOT lost on a script "rerun" (reruns just
    re-execute app.py top-to-bottom; the .db file on disk is untouched).
  - BUT if the app goes to sleep and wakes up again, gets redeployed,
    or the underlying container is recycled, the filesystem resets to
    whatever was in your GitHub repo. Any users registered during a
    live session can be WIPED OUT.
This is FINE for a hackathon demo (register your team's faces right
before presenting, in the same session you demo in). It is NOT
production-grade storage. For production you would use a real hosted
database (e.g. Postgres/Supabase/Firebase) instead of a local SQLite
file. Tell your team this clearly so nobody is surprised on demo day.
"""

import os
import sqlite3
import numpy as np


class Database:
    def __init__(self, db_path: str = "database/faces.db"):
        db_dir = os.path.dirname(db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS face_embeddings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                embedding BLOB NOT NULL
            )
        """)
        conn.commit()
        conn.close()

    def add_user(self, name: str, embeddings: list):
        """
        Save multiple embeddings (one row per sample) for a person.
        Storing several samples per person (not just one) makes matching
        more robust to lighting/angle differences.
        """
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        for emb in embeddings:
            emb_bytes = np.asarray(emb, dtype=np.float32).tobytes()
            cur.execute(
                "INSERT INTO face_embeddings (name, embedding) VALUES (?, ?)",
                (name, emb_bytes),
            )
        conn.commit()
        conn.close()

    def get_all_embeddings(self):
        """
        Returns a list of (name, embedding) tuples for every stored sample.
        """
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("SELECT name, embedding FROM face_embeddings")
        rows = cur.fetchall()
        conn.close()

        result = []
        for name, blob in rows:
            embedding = np.frombuffer(blob, dtype=np.float32)
            result.append((name, embedding))
        return result

    def list_users(self):
        """Returns a list of unique registered names."""
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT name FROM face_embeddings")
        names = [row[0] for row in cur.fetchall()]
        conn.close()
        return names

    def count_samples(self, name: str) -> int:
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM face_embeddings WHERE name = ?", (name,))
        count = cur.fetchone()[0]
        conn.close()
        return count

    def delete_user(self, name: str):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("DELETE FROM face_embeddings WHERE name = ?", (name,))
        conn.commit()
        conn.close()
